<?php @session_start();

\FormViewCreation\Logging::signingOut();
echo '<META HTTP-EQUIV="Refresh" Content="2; URL=/">';
?>