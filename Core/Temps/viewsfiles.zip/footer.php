<section>
<!--footer code come here-->
    <?php \Assest\Assest::loadJavaScript('Js'); ?>
</section>
</div>
</body>
</html>